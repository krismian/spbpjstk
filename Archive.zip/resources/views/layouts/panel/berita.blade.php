<div class="col-md-2 links">
    <h3>Pengaduanku</h3>
    <p>Data tidak ditemukan</p>
    <h3>Beritaku</h3>
    <a href="/tulisberita" class="btn btn-primary">Tulis Berita</a>
</div>