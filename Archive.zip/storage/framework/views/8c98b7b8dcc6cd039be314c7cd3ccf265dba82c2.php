<?php $__env->startSection('berita'); ?>
    <div class="text-justify">
        <h2><?php echo e($berita->judul); ?></h2>
        <p><?php echo e($berita->isi); ?></p>
        <div class="komentar">
            <h4>Komentar :</h4>
            <?php $__currentLoopData = $komentar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $komen): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <p><?php echo e($komen->isi); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </div>
        <h4>Komentar Anda :</h4>
        <?php if(Auth::check()): ?>
            <?php echo e(Form::open(['route' => ['post.komentar', $berita->id]])); ?>

            <div class="form-group">
                <?php echo e(Form::textarea('komentar', null, ['class' => 'form-control'])); ?>

            </div>

            <div class="form-group">
                <?php echo e(Form::submit('Kirim', ['class' => 'form-control btn btn-primary'])); ?>

            </div>
            <?php else: ?>
            <p>Jika Anda anggota Serikat Pekerja BPJS Ketenagakerjaan, silahkan login untuk dapat menulis komentar Anda</p>
            <?php echo e(Form::close()); ?>

        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>