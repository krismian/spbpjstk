<?php $__env->startSection('berita'); ?>
    <?php echo e(Form::open()); ?>

    <div class="form-group spasi">
        <?php echo e(Form::label('judul', 'Judul')); ?>

        <?php echo e(Form::text('judul', null, ['class' => 'form-control', 'placeholder' => 'tulis judul berita'])); ?>

        <?php echo e(Form::textarea('isi', null, ['class' => 'form-control', 'placeholder' => 'tulis judul berita', 'id' => 'ckeditor'])); ?>

    </div>
    <?php echo e(Form::close()); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="/vendor/unisharp/laravel-ckeditor/ckeditor.js"></script>
    <script>
        CKEDITOR.replace( 'ckeditor', {
            filebrowserImageBrowseUrl: '/laravel-filemanager?type=Images',
            filebrowserImageUploadUrl: '/laravel-filemanager/upload?type=Images&_token=<?php echo e(csrf_token()); ?>',
            filebrowserBrowseUrl: '/laravel-filemanager?type=Files',
            filebrowserUploadUrl: '/laravel-filemanager/upload?type=Files&_token=<?php echo e(csrf_token()); ?>'
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>