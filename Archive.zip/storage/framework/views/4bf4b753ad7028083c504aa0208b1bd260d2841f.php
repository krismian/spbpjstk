<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">
        <div class="item active">
            <img src="pictures/DSC_5025.jpg" alt="...">
            <div class="carousel-caption">
                <h3 style="font-weight: bold">Penanaman Pohon</h3>
                <p style="font-weight: bold">Jogjakarta, 1 Desember 2016</p>
            </div>
        </div>
        <div class="item">
            <img src="pictures/DSC_4167.jpg" alt="...">
            <div class="carousel-caption">
                <h3 style="font-weight: bold">Munaslub SP BPJS Ketenagakerjaan 2016</h3>
                <p style="font-weight: bold">Jogjakarta, 1 Desember 2016</p>
            </div>
        </div>
        <div class="item">
            <img src="pictures/DSC_5123.jpg" alt="...">
            <div class="carousel-caption">
                <h3 style="font-weight: bold">Penanaman Pohon</h3>
                <p style="font-weight: bold">Jogjakarta, 1 Desember 2016</p>
            </div>
        </div>

    </div>

    <!-- Controls -->
    
</div>